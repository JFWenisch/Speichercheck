Deutsch :

Speichercheck ist ein Programm das helfen soll,dass Speichervolumen eines Laufwerks zu �berwachen und Statistiken zu erstellen.

Speichercheck kann :

- Alle 10 Sekunden den Speicherplatz des Laufwerks
  �berpr�fen.

- Eine Warnung bei einem benutzerdefinierten 
  Speichervolumen ausgeben.

-Alle erfassten Daten im Programm und in einer .txt Datei   protokollieren.

-Die erfassten Daten grafisch in einem Diagramm  darstellen.

- Bei einem benutzerdefinierten Speichervolumen
 eine E-Mail versenden in der die aktuelle Uhrzeit und
 das aktuelle Speichervolumen mitgeteilt wird.
 Bei Bedarf kann das Log File angeh�ngt werden.


English :

Speichercheck is a program which monitors and logs every 10 seonds your present free disk space and creates a diagram according to this values. erstellen.

Speichercheck does :

- Monitors every 10 seconds your present
  free disk space.

- Gives out a warning if the disk space
  falls under a user defined value

-It logs the disk space and saves it 
 local in a text file

- It creates a diagramm according to the
  saved log

- It can inform you via E-Mail if your   
  disk space falls under a user defined
  value. In this E_mail you will see the  
  date and time,your disk space and if  
  you chose the option the log file will  
  be attached on the E-Mail-
